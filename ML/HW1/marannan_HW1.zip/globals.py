__author__ = 'ashokmarannan'
import sys

#globals
train_set_file = "nofile"
test_set_file = "nofile"
train_set_data = {}
test_set_data = {}
attributes_list = {}
attributes_lable = []
class_label = []
class_entropy = 0
root = 0
