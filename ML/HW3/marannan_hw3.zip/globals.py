__author__ = 'ashokmarannan'
import sys

#globals
train_set_file = "nofile"
test_set_file = "nofile"
nort = 'n'
train_set_data = {}
test_set_data = {}
attribute_names = []
attribute_values = {}
class_names = []
class_values = {}
class_count = {}
y_1 = 0
y_2 = 0
def debug_print(debug_str):
    print debug_str
    
