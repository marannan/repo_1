__author__ = 'ashokmarannan'
import sys
import os
import math
import random
from globals import *
from get_data import * #import get_data, get_attribute_values, get_attribute_names, start_jvm, stop_jvm


def populate_data():
    global train_set_data, test_set_data, attribute_names, attribute_values, class_names
    
    train_set_data = get_arff_data(train_set_file);
    test_set_data = get_arff_data(test_set_file);
    attribute_names = get_attribute_names_1(train_set_file)
    attribute_values = get_attribute_values(train_set_file);
    #attribute_values_1 = get_attribute_values_1(train_set_file);
    
    for attri in attribute_values:
        if attri == "class" or attri == "Class":
            class_values[attri] = attribute_values[attri]
    
    #debug_print(str(train_set_data)
    #debug_print(str(test_set_data))
    debug_print(str(attribute_names))
    #debug_print(str(attribute_values))
    #debug_print(str(attribute_values_1))
    
    #for attri in attribute_names:
        #debug_print("attributes name:\n" + str(attri))

    #for attri_val in attribute_values:
        #debug_print("attributes values:\n" + str(attri_val) + str(attribute_values[attri_val]))
        
    return

def get_input():
    global train_set_file, test_set_file
    global nort
    
    try:
        train_set_file = sys.argv[1]
        if(os.path.isfile(train_set_file) == False):
            print "error: train set %s cannot be opened",(data_set_file)
            sys.exit(0)
            
        test_set_file = sys.argv[2]
        if(os.path.isfile(test_set_file) == False):
            print "error: test set %s cannot be opened",(data_set_file)
            sys.exit(0)    
    
       
        nort = str(sys.argv[3])    #n or t
        
    except ValueError:
        print("error: getting input") 
        sys.exit(0)

    #debug_print(str("input:"))
    #debug_print(str("train set file = " + train_set_file))
    #debug_print(str("test set file = " + test_set_file))
    #debug_print(str(nort))

    return 0

def find_prob_class(train_set_data):
    global y_1
    global y_2
    inst_total = len(train_set_data)
    
    for inst in train_set_data:
        if inst[class_values.keys()[0]] == class_values[class_values.keys()[0]][0]:
            y_1 = y_1 + 1
        
        if inst[class_values.keys()[0]] == class_values[class_values.keys()[0]][1]:
            y_2 = y_2 + 1    
    
    p_y_1 = float(y_1 + 1)/float(inst_total + 2)
    p_y_2 = float(y_2 + 1)/float(inst_total + 2)    
    
    return (p_y_1, p_y_2)

def find_prob(test_attri, test_attri_val):
    global y_1, y_2
    x_y_1 = 0
    x_y_2 = 0
    inst_total = len(train_set_data)
    test_attri_val_count = len(attribute_values[test_attri])
    class_count = 2    
    
    for inst in train_set_data:
        #debug_print(str(test_attri) + " : " + str(inst[test_attri]) + " : "+ str(inst["class"]))
        if(inst[test_attri] == test_attri_val) and inst[class_values.keys()[0]] == class_values[class_values.keys()[0]][0]:
            x_y_1 = x_y_1 + 1
                
        if(inst[test_attri] == test_attri_val) and inst[class_values.keys()[0]] == class_values[class_values.keys()[0]][1]:
            x_y_2 = x_y_2 + 1        
      
    num_1 = x_y_1 + 1 
    den_1 = y_1 + test_attri_val_count
    p_x_y_1 = float(num_1)/float(den_1)
    
    
    num_2 = x_y_2 + 1 
    den_2 = y_2 + test_attri_val_count
    p_x_y_2 = float(num_2)/float(den_2)
    
    #debug_print(str(test_attri) + " : " +str(test_attri_val) + " count: " + str(x_y_1) + " " + str(p_x_y_1)) 
    #debug_print(str(test_attri) + " : " +str(test_attri_val) + " count: " + str(x_y_2)+ " " + str(p_x_y_2)) 
    
    return (p_x_y_1, p_x_y_2)
                
def bayesnet():
    p_y_1 = 0
    p_y_2 = 0
    correct = 0

    for name in attribute_names:
        if name != class_values.keys()[0]:
            debug_print(str(name) + " " + "class")
   
    debug_print("")
    
    (p_y_1, p_y_2) = find_prob_class(train_set_data) 
    
    for inst in test_set_data:
        p_xs_y_1 = []
        p_xs_y_2 = [] 
        p_x_y_1 = 1
        p_x_y_2 = 1        
        #debug_print(str(inst))
        for attri in inst:
            if attri != class_values.keys()[0]:
                p_X_y_1, p_X_y_2 = find_prob(attri, inst[attri])
                p_xs_y_1.append(p_X_y_1)
                p_xs_y_2.append(p_X_y_2)
         
        for item in p_xs_y_1:
            p_x_y_1 = float(p_x_y_1) * float(item)
        
        for item in p_xs_y_2:
            p_x_y_2 = float(p_x_y_2) * float(item)
    
    
        p_y_1_x = (float(p_x_y_1) * float(p_y_1)) / ((float(p_x_y_1) * float(p_y_1)) + (float(p_x_y_2) * float(p_y_2)))
        p_y_2_x = (float(p_x_y_2) * float(p_y_2)) / ((float(p_x_y_2) * float(p_y_2)) + (float(p_x_y_1) * float(p_y_1)))

       
        if p_y_1_x > p_y_2_x:
            debug_print(str(attribute_values[class_values.keys()[0]][0]) + " " + str(inst[class_values.keys()[0]]) + " " + str('{0:.16f}'.format(p_y_1_x)))
            if  str(attribute_values[class_values.keys()[0]][0]) == str(inst[class_values.keys()[0]]):
                correct = correct + 1            
        else:
            debug_print(str(attribute_values[class_values.keys()[0]][1]) + " " + str(inst[class_values.keys()[0]]) + " " + str('{0:.16f}'.format(p_y_2_x)))
            if  str(attribute_values[class_values.keys()[0]][1]) == str(inst[class_values.keys()[0]]):
                correct = correct + 1            
        
        
      
    debug_print("")     
    debug_print(str(correct))
        
        
    return 

def predict():
    global test_set_data
    
    if(nort == "n"):
        bayesnet()

    elif(nort == "t"):
        tan()
        
    else:
        bayesnet()


def calculate_output(training_instance):
    
    return output

def main():
    start_jvm()
    get_input()
    populate_data()
    predict()  
    stop_jvm()
    return 0

if __name__ == "__main__":
    main()