require('../lib');
module.exports = sinon = require("sinon");
module.exports = expect = require("chai").expect
