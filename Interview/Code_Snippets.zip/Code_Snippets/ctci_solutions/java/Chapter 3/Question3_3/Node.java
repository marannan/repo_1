package Question3_3;

public class Node {
	public Node above;
	public Node below;
	public int value;
	public Node(int value) {
		this.value = value;
	}
}
