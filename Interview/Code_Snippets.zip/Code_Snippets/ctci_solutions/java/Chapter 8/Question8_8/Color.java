package Question8_8;

public enum Color {
	White, Black
}
