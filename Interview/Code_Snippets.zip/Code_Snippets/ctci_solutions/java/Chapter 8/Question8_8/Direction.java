package Question8_8;

public enum Direction {
	left, right, up, down
}
