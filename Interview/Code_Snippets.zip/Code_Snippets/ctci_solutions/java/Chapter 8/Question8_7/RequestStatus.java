package Question8_7;

public enum RequestStatus {
	Unread, Read, Accepted, Rejected
}
