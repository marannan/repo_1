package Question8_4;

public enum VehicleSize {
	Motorcycle, 
	Compact, 
	Large,
}
