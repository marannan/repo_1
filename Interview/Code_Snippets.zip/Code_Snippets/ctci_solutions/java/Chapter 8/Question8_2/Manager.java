package Question8_2;

class Manager extends Employee {
    public Manager() {
    	rank = Rank.Manager;
    }
}
