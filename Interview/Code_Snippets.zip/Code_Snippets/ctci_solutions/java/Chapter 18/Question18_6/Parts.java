package Question18_6;

public class Parts {
	public int left;
	public int right;
	public Parts(int l, int r) {
		left = l;
		right = r;
	}
}
