require 'rspec'
# require 'debugger';debugger;1
Dir["./lib/**/*.rb"].each {|f| require f}
