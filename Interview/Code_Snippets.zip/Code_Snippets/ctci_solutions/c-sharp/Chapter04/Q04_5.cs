﻿
using ctci.Contracts;

namespace Chapter04
{
    public class Q04_5 : IQuestion
    {
        // Please see IsBst() implementation in TreeNode
        public void Run()
        {}
    }
}
