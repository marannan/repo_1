﻿
namespace ctci.Contracts
{
    public interface IQuestion
    {
        void Run();
    }
}
