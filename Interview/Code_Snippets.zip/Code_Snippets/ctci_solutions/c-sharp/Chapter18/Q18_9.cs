﻿
using System;
using System.Collections.Generic;
using System.Text;

using ctci.Contracts;
using ctci.Library;
using System.Collections;

namespace Chapter18
{
    public class Q18_9 : IQuestion
    {
        public void Run()
        {}
    }
}
