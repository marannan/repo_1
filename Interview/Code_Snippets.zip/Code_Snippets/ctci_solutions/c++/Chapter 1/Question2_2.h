#ifndef __Question_2_2_h__
#define __Question_2_2_h__

#include <string>

using std::string;

class Question2_2
{
public:
    int run();
};

#endif // __Question_2_2_h__