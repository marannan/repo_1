#ifndef __Question_2_5_h__
#define __Question_2_5_h__

#include <string>

using std::string;

class Question2_5
{
public:
    int run();
};

#endif // __Question_2_5_h__