Tree * LCA(Tree *root, Tree *A, Tree *B)
{
	// Base case
    if (root == NULL) return NULL;
 
    // If either n1 or n2 matches with root's key, report
    // the presence by returning root (Note that if a key is
    // ancestor of other, then the ancestor key becomes LCA
    if (root->key == A || root->key == B)
        return root;
 
    // Look for keys in left and right subtrees
    Node *left_lca  = findLCA(root->left, A, B);
    Node *right_lca = findLCA(root->right, A, B);
 
    // If both of the above calls return Non-NULL, then one key
    // is present in once subtree and other is present in other,
    // So this node is the LCA
    if (left_lca && right_lca)  return root;
 
    // Otherwise check if left subtree or right subtree is LCA
    return (left_lca != NULL)? left_lca: right_lca;
}